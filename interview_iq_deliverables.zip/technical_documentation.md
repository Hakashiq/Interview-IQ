# InterviewIQ: Enterprise-Grade AI Mock Interview & Resume Analyzer Platform
## Technical Architecture & Developer Documentation

---

## 1. Project Overview

### Purpose & Problem Solved
**InterviewIQ** is an enterprise-ready, high-performance web platform designed to close the technical skill-gap between standard software development training and real-world industry requirements. The platform automates:
* **Interactive AI Mock Interviews**: Simulating domain-specific, role-targeted interviews using configurable AI interviewer personas (friendly, professional, strict, robotic) with text answers and real-time text-to-speech voice generation.
* **Intelligent Proctoring & Exam Integrity**: Multi-faceted cheating detection including page blur/focus listeners (tab switching), browser copy-paste restrictions, and client-side webcam proctoring (gaze tracking and head movement yaw/pitch detection) powered by **Google MediaPipe FaceLandmarker**.
* **Multi-Dimensional AI Evaluation**: Dynamic, NLP-driven grading scoring candidate answers across technical accuracy, relevance, completeness, vocabulary, and pressure composure, complete with specific recommendations.
* **ATS Resume Analyzer & Optimiser**: Base64 document extraction (PDF/Word), keyword alignment verification, dynamic ATS rule engine score calculations, and real-time structured Markdown resume builder.
* **Collaborative Mentor & Support Hub**: Dashboards for educators to track performance matrices, verify fraud violations, review complaints, and recommend roadmaps.

### Target Users
1. **Students & Candidates**: Seeking realistic, adaptive interview prep and resume optimization.
2. **Mentors & Educators**: Tracking student success, reviewing fraud logs, and guiding roadmap suggestions.
3. **Platform Administrators**: Overseeing configurations, editing/versioning system prompts, and auditing logs.

### Tech Stack
* **Frontend**: React (v19.2.6), Single Page Application (SPA), styled with custom CSS variables and utility classes, Vite (v8.0.12) bundler, TailwindCSS (v3.4.19), Chart.js via `react-chartjs-2` for performance analytics.
* **Backend**: Spring Boot (v3.3.5) with Java 21, Spring Data JPA, Hibernate, Spring Security (JWT state-management), WebSockets (STOMP), and MySQL.
* **AI Service Layer**: Python (v3.12) FastAPI (v0.115.0), Google Generative AI SDK (`gemini-2.0-flash` model), PyMuPDF and `python-docx` for file parsing, and spaCy (v3.7.0) for local NLP heuristics.
* **Infrastructure**: Nginx (reverse proxy gateway), Redis (cache manager), Docker & Docker Compose (container orchestration).

---

## 2. Architecture

```mermaid
graph TD
    Client[React SPA Client - Port 5173] <-->|HTTP / WS| Nginx[Nginx Reverse Proxy - Port 80]
    Nginx <-->|/api/| SpringBoot[Spring Boot Backend - Port 8080]
    Nginx <-->|/ai/| FastAPI[FastAPI AI Service - Port 8000]
    SpringBoot <-->|JPA / Hibernate| MySQL[(MySQL Database - Port 3306)]
    SpringBoot <-->|In-Memory Cache| Redis[(Redis Cache - Port 6379)]
    FastAPI <-->|REST| SpringBoot
    FastAPI <-->|HTTPS| GeminiAPI[Google Gemini 2.0 API]
```

### High-Level Architecture
The system employs a **Microservices-adjacent containerized architecture** aggregated behind an **Nginx Gateway Reverse Proxy**:
* **Frontend Tier (Client)**: The React app executes client-side face landmark proctoring using **Google MediaPipe WASM libraries** to minimize server GPU/CPU load. It connects asynchronously to the gateway.
* **Gateway Tier (Nginx)**: Performs routing based on path rules: routes API calls to the Spring Boot backend, WebSockets to backend STOMP endpoints, and AI requests to FastAPI.
* **Application Tier (Spring Boot)**: A stateless, multi-layered REST controller that handles core transactional state, authentication, socket broadcasts, and schedules alerts. It enables **Java 21 Virtual Threads** for scalable thread execution.
* **AI Engine Tier (FastAPI)**: Translates resume parsing, ATS scoring, question generation, and evaluations into LLM instructions, sending requests to Google Gemini 2.0 Flash with local heuristic NLP fallbacks.

### Data Flow Example (Answer Submission)
1. **Submit Answer**: Client posts student response to `/api/interviews/{id}/submit-answer` ([InterviewController.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/controller/InterviewController.java)).
2. **Retrieve Context**: [InterviewServiceImpl.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/service/impl/InterviewServiceImpl.java) fetches active interview and question state from MySQL database.
3. **AI Client Call**: Backend delegates evaluation to [AIClientServiceImpl.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/service/impl/AIClientServiceImpl.java) which sends a REST request to FastAPI's `/answers/evaluate` ([evaluation_router.py](file:///D:/Antigravity/interview-iq/ai-service/routers/evaluation_router.py)).
4. **AI Inference & Fallback**: FastAPI calls Gemini API. If the API key is missing or fails, it falls back to a local string similarity and concept tokenisation parser (`_get_mock_evaluation()`).
5. **Persist & Return**: The evaluated rubrics (Accuracy, Relevance, etc.) are returned to Spring Boot, which saves the `Feedback` entity, schedules notifications, and outputs the response.

### Design Patterns Used
* **Dual-Tier Resiliency (Strategy/Fallback)**: Used in all AI FastAPI routes to switch to local heuristics if the external LLM fails.
* **Interceptor Pattern**: Axios request/response interceptors to handle token injection and automated refresh attempts.
* **Filter Chain Pattern**: Spring Security configuration injecting custom JWT filter filters prior to Standard user validation.
* **Data Seeding & Migration**: Dynamic Hibernate `ddl-auto: update` mapping coupled with `DataSeeder.java` component.

---

## 3. File-by-File Breakdown

### 3.1 AI Service Module (`ai-service/`)

* **[config.py](file:///D:/Antigravity/interview-iq/ai-service/config.py)**
  * **Purpose**: Holds configurations via Pydantic `BaseSettings` and manages Google Generative AI SDK initialization.
  * **Key Components**: `Settings` (maps `GEMINI_API_KEY`, `app_name`, `debug`), `get_gemini_model(temperature=0.7)` (initialises and returns `GenerativeModel('gemini-2.0-flash')` or returns `None`).
* **[main.py](file:///D:/Antigravity/interview-iq/ai-service/main.py)**
  * **Purpose**: Entry point for FastAPI. Mounts sub-routers, registers CORS policies, and serves health checks on `GET /health`.
* **[utils.py](file:///D:/Antigravity/interview-iq/ai-service/utils.py)**
  * **Purpose**: Text parser that extracts JSON responses from LLM markdown fences.
  * **Key Components**: `parse_gemini_json(text)` cleans up markdown wrappers (` ```json ... ``` `) and runs `json.loads`.
* **[models/schemas.py](file:///D:/Antigravity/interview-iq/ai-service/models/schemas.py)**
  * **Purpose**: Container for all Pydantic Request/Response validation models (DTOs).
  * **Key Structs**: `ResumeParseRequest`, `ExtractedResume` (education, experience list), `ResumeScoreResponse` (various scores, missing skills, improvements), `QuestionGenerateRequest`, `EvaluateAnswerRequest`, `EvaluationResponse` (rubric scores, improvements), `CommunicationAnalysisRequest`, `RecommendationResponse`.
* **[routers/question_router.py](file:///D:/Antigravity/interview-iq/ai-service/routers/question_router.py)**
  * **Purpose**: Generates role-based questions based on tech skills and difficulty.
  * **Key Endpoint**: `POST /generate` (uses Gemini prompt aligned to developer roadmaps, or falls back to pre-seeded static bank via `_get_mock_questions()`).
* **[routers/recommendation_router.py](file:///D:/Antigravity/interview-iq/ai-service/routers/recommendation_router.py)**
  * **Purpose**: Produces personalized roadmaps.
  * **Key Endpoint**: `POST /generate` (takes weak topics and returns a weekly study roadmap).
* **[routers/evaluation_router.py](file:///D:/Antigravity/interview-iq/ai-service/routers/evaluation_router.py)**
  * **Purpose**: Scores answers and transcript fluency.
  * **Key Endpoints**:
    * `POST /evaluate`: Scores answers on technical accuracy, relevance, and completeness.
    * `POST /communication`: Scans transcripts for filler words (`"um"`, `"uh"`, `"like"`, `"actually"`) and returns fluency metrics.
    * `_get_mock_evaluation()`: Custom local NLP fallback mapping answer token overlap, length ratio, and negation matching.
* **[routers/resume_router.py](file:///D:/Antigravity/interview-iq/ai-service/routers/resume_router.py)**
  * **Purpose**: Decodes base64 resumes, extracts text, maps skills, and scores ATS compatibility.
  * **Key Endpoints**:
    * `POST /parse`: Decodes Base64 stream, extracts PDF (`fitz`) or Docx (`docx`) text, and uses Gemini to map entities.
    * `POST /score`: Computes 5 different score metrics, checks missing skills, and formats an optimized resume in Markdown.
* **[create_presentation.py](file:///D:/Antigravity/interview-iq/ai-service/create_presentation.py)**
  * **Purpose**: A standalone utility script utilizing `python-pptx` to compile slide decks summarizing the platform.

### 3.2 Java Spring Boot Backend (`backend/`)

* **[InterviewIqApplication.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/InterviewIqApplication.java)**
  * **Purpose**: Standard entry point. Enables caching, scheduling, and JPA auditing.
* **[config/CorsConfig.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/config/CorsConfig.java)**
  * **Purpose**: CORS configuration routing allowed origins.
* **[config/DataSeeder.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/config/DataSeeder.java)**
  * **Purpose**: Seeds basic roles (`ROLE_STUDENT`, `ROLE_ADMIN`, `ROLE_MENTOR`), test users, question banks, skills, and configuration values.
* **[config/NotificationScheduler.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/config/NotificationScheduler.java)**
  * **Purpose**: Cron scheduler running every minute (`0 * * * * *`) that alerts users of interviews scheduled in the next 30 minutes.
* **[config/RedisConfig.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/config/RedisConfig.java)**
  * **Purpose**: Registers in-memory caches for dashboard stats, questions, and leaderboards.
* **[config/SecurityConfig.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/config/SecurityConfig.java)**
  * **Purpose**: Configures Spring Security with stateless sessions, JWT filter injection, and route permissions.
* **[config/WebSocketConfig.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/config/WebSocketConfig.java)**
  * **Purpose**: Maps `/ws/interview` to STOMP protocol.
* **[security/JwtAuthenticationFilter.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/security/JwtAuthenticationFilter.java)**
  * **Purpose**: Extracts bearer tokens from authorization header, validates them, and binds the principal to the security thread context.
* **[security/JwtTokenProvider.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/security/JwtTokenProvider.java)**
  * **Purpose**: Utility class to compile and parse HS512 keys, validate claims, and extract emails.
* **[exception/GlobalExceptionHandler.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/exception/GlobalExceptionHandler.java)**
  * **Purpose**: Intercepts exception events (resource not found, validation error, file limit exceeded) and serializes them into standard JSON structures.
* **[service/impl/AIClientServiceImpl.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/service/impl/AIClientServiceImpl.java)**
  * **Purpose**: Consumes the Python FastAPI endpoints using `RestTemplate`.
* **[service/impl/AuthServiceImpl.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/service/impl/AuthServiceImpl.java)**
  * **Purpose**: Processes registers and logins. Enforces temporary suspensions if user accounts contain active fraud penalties.
* **[service/impl/InterviewServiceImpl.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/service/impl/InterviewServiceImpl.java)**
  * **Purpose**: Controls interview flow state. Prepares questions from bank, records intermediate responses, gets evaluations, compiles score averages, and closes interviews.
* **[service/impl/ResumeServiceImpl.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/service/impl/ResumeServiceImpl.java)**
  * **Purpose**: Manages resume uploads. Stores files, triggers parsing/scoring APIs, extracts associated skills, and maps improvement suggestions.

### 3.3 Frontend React Module (`frontend/`)

* **[src/api/axios.js](file:///D:/Antigravity/interview-iq/frontend/src/api/axios.js)**
  * **Purpose**: Custom Axios instance with interceptors that inject JWT authorization headers and automate token renewal on receiving a `401 Unauthorized` response.
* **[src/context/AuthContext.jsx](file:///D:/Antigravity/interview-iq/frontend/src/context/AuthContext.jsx)**
  * **Purpose**: Distributes authentication state, user roles, login, register, and logout handlers globally.
* **[src/components/layout/Sidebar.jsx](file:///D:/Antigravity/interview-iq/frontend/src/components/layout/Sidebar.jsx)**
  * **Purpose**: Renders collapsable sidebar navigation, toggling accessible tabs based on current user roles (Admin panel, Mentor hub, Student main menu).
* **[src/pages/InterviewSessionPage.jsx](file:///D:/Antigravity/interview-iq/frontend/src/pages/InterviewSessionPage.jsx)**
  * **Purpose**: **Core proctoring and interactive workspace**.
  * **Key Logic**:
    * Web Speech Synthesis translates questions to customizable voice streams.
    * Speech Recognition (Speech-to-Text) translates user speech into answer input.
    * Gaze & Head Proctoring: Imports MediaPipe FaceLandmarker, computes eye-to-nose Euclidean coordinates to calculate yaw and pitch. Triggers cheat warnings if head/eyes turn away or multiple people are seen.
    * Action listeners track window blur events (tab switching) and restrict copy-paste.

---

## 4. Data Layer

The backend uses **Spring Data JPA** with Hibernate mapping. Below is a detailed schema representation of the relational model:

```mermaid
erDiagram
    USERS ||--o{ INTERVIEWS : has
    USERS ||--o{ RESUMES : uploads
    USERS ||--o{ RECOMMENDATIONS : receives
    USERS ||--o{ NOTIFICATIONS : gets
    USERS ||--o{ REFRESH_TOKENS : has
    USERS ||--o{ STUDENT_SKILLS : proficiency
    USERS }|--|| USER_ROLES : has
    USER_ROLES ||--|{ ROLES : matches
    
    INTERVIEWS ||--|{ INTERVIEW_QUESTIONS : contains
    QUESTIONS ||--|{ INTERVIEW_QUESTIONS : referenced-in
    CATEGORIES ||--|{ QUESTIONS : classifies
    INTERVIEW_QUESTIONS ||--|| ANSWERS : has
    ANSWERS ||--|| FEEDBACK : evaluates
    
    RESUMES ||--|{ RESUME_SKILLS : contains
    SKILLS ||--|{ RESUME_SKILLS : referenced-in
    SKILLS ||--|{ STUDENT_SKILLS : referenced-in
```

### Table Definitions

| Table Name | JPA Entity | Key Columns & Types | Relationships |
| :--- | :--- | :--- | :--- |
| `users` | [User.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/User.java) | `id` (BIGINT PK), `email` (VARCHAR), `password` (VARCHAR), `full_name` (VARCHAR), `phone` (VARCHAR), `avatar_url` (VARCHAR), `enabled` (BOOL), `banned_until` (DATETIME), `education` (VARCHAR), `id_card_path` (VARCHAR) | `@ManyToMany` with `roles` via join table `user_roles` |
| `roles` | [Role.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Role.java) | `id` (BIGINT PK), `name` (VARCHAR) | Referenced by `users` |
| `questions` | [Question.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Question.java) | `id` (BIGINT PK), `category_id` (BIGINT FK), `question_text` (TEXT), `ideal_answer` (TEXT), `difficulty` (VARCHAR), `type` (VARCHAR), `ai_generated` (BOOL) | `@ManyToOne` with `categories` |
| `categories` | [Category.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Category.java) | `id` (BIGINT PK), `name` (VARCHAR), `type` (VARCHAR) | Referenced by `questions` |
| `interviews` | [Interview.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Interview.java) | `id` (BIGINT PK), `user_id` (BIGINT FK), `job_role` (VARCHAR), `difficulty` (VARCHAR), `mode` (VARCHAR), `overall_score` (INT), `communication_analysis` (TEXT), `started_at` (DATETIME), `completed_at` (DATETIME), `scheduled_at` (DATETIME), `notified_30m` (BOOL) | `@ManyToOne` with `users`, `@OneToMany` with `interview_questions` |
| `interview_questions`| [InterviewQuestion.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/InterviewQuestion.java)| `id` (BIGINT PK), `interview_id` (BIGINT FK), `question_id` (BIGINT FK), `sequence_order` (INT) | `@ManyToOne` with `interviews`, `@ManyToOne` with `questions`, `@OneToOne` with `answers` |
| `answers` | [Answer.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Answer.java) | `id` (BIGINT PK), `interview_question_id` (BIGINT FK), `answer_text` (TEXT), `audio_path` (VARCHAR), `transcript` (TEXT), `time_taken_seconds` (INT), `submitted_at` (DATETIME) | `@OneToOne` with `interview_questions`, `@OneToOne` with `feedback` |
| `feedback` | [Feedback.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Feedback.java) | `id` (BIGINT PK), `answer_id` (BIGINT FK), `technical_accuracy` (INT), `completeness` (INT), `communication` (INT), `relevance` (INT), `confidence` (INT), `overall_score` (INT), `strengths` (TEXT), `weaknesses` (TEXT), `improvements` (TEXT) | `@OneToOne` with `answers` |
| `resumes` | [Resume.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Resume.java) | `id` (BIGINT PK), `user_id` (BIGINT FK), `file_path` (VARCHAR), `file_name` (VARCHAR), `raw_text` (TEXT), `resume_score` (INT), `ats_score` (INT), `recruiter_score` (INT), `technical_depth_score` (INT), `interview_readiness_score` (INT), `final_resume_content` (TEXT), `extracted_data` (TEXT), `improvement_suggestions` (TEXT), `uploaded_at` (DATETIME) | `@ManyToOne` with `users`, `@ManyToMany` with `skills` via `resume_skills` |
| `skills` | [Skill.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Skill.java) | `id` (BIGINT PK), `name` (VARCHAR), `category` (VARCHAR) | Referenced in `resume_skills` & `student_skills` |
| `student_skills` | [StudentSkill.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/StudentSkill.java) | `id` (BIGINT PK), `user_id` (BIGINT FK), `skill_id` (BIGINT FK), `proficiency` (VARCHAR) | `@ManyToOne` with `users`, `@ManyToOne` with `skills` |
| `violations` | [Violation.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/Violation.java) | `id` (BIGINT PK), `user_id` (BIGINT), `username` (VARCHAR), `violation_type` (VARCHAR), `details` (VARCHAR), `timestamp` (DATETIME) | Standalone proctoring metrics audit log |
| `admin_prompts` | [AdminPrompt.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/AdminPrompt.java) | `id` (BIGINT PK), `prompt_type` (VARCHAR), `name` (VARCHAR), `prompt_text` (TEXT), `version` (INT), `created_at` (DATETIME) | Prompts configuration and versioning engine |
| `system_config` | [SystemConfig.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/entity/SystemConfig.java) | `config_key` (VARCHAR PK), `config_value` (VARCHAR) | Central global settings registry |

---

## 5. API Documentation

Authentication is state-managed utilizing stateless JWTs. Token strings must be included in the header of restricted requests: `Authorization: Bearer <accessToken>`.

### Authentication Endpoints
* **`POST /api/auth/register`**: Creates new user profile.
  * *Request Body*: JSON (`fullName`, `email`, `password`, `phone`, `role` (e.g. `ROLE_STUDENT` or `ROLE_MENTOR`), `education`, `idCardPath` (optional)).
  * *Response*: JWT payload details (`accessToken`, `refreshToken`, `userId`, `email`, `fullName`, `roles`).
* **`POST /api/auth/login`**: Authenticates user profile.
  * *Request Body*: JSON (`email`, `password`).
  * *Response*: JWT credentials, or 403 Forbidden if user is currently suspended.
* **`POST /api/auth/refresh`**: Generates a new access token using a refresh token.
  * *Request Body*: JSON (`refreshToken`).
  * *Response*: `{"accessToken": "...", "refreshToken": "..."}`.
* **`POST /api/auth/logout`**: Invalidates refresh token.
  * *Request Body*: JSON (`refreshToken`).
  * *Response*: `{"message": "Logged out successfully"}`.

### Active Interview Engine Endpoints
* **`POST /api/interviews/start`**: Creates a new mock session.
  * *Request Body*: JSON (`jobRole`, `difficulty` (`EASY`, `INTERMEDIATE`, `HARD`), `mode` (`TEXT`), `skills` (`List[str]`)).
  * *Response*: Details of interview structure and assigned question count.
* **`GET /api/interviews/{id}/next-question`**: Fetches the next question in sequence order.
  * *Response*: `{"id": 41, "questionText": "...", "sequenceOrder": 2}` or `204 No Content` if completed.
* **`POST /api/interviews/{id}/submit-answer`**: Submits a response.
  * *Request Body*: JSON (`answerText`, `timeTakenSeconds`).
  * *Response*: Feedback metrics (`technicalAccuracy`, `completeness`, `overallScore`, `strengths`, `improvements`).
* **`POST /api/interviews/{id}/complete`**: Finalizes the session and computes overall scores.

### Resume Analyzer Endpoints
* **`POST /api/resumes/upload`**: Uploads and parses document.
  * *Request Body*: Form multipart-file (`file`).
  * *Response*: Extracted structured data, scores, suggestions list.
* **`GET /api/resumes/latest`**: Fetches details of the latest uploaded resume.

### Collaborative Mentor Workspace
* **`GET /api/admin/feedback`**: Lists student reviews and complaints.
* **`GET /api/admin/violations`**: Returns logged proctoring infractions.
* **`POST /api/admin/users/{id}/ban`**: Blocks a user.
  * *Request Body*: JSON (`durationDays`, `reason`).

---

## 6. Configuration & Environment

### Environment Variables

| Variable Name | Default Value | Description |
| :--- | :--- | :--- |
| `SPRING_DATASOURCE_URL` | `jdbc:mysql://localhost:3306/interviewiq` | Main database URL connection string |
| `SPRING_DATASOURCE_USERNAME` | `root` | Database user profile |
| `SPRING_DATASOURCE_PASSWORD` | `root123` | Database access password |
| `SPRING_REDIS_HOST` | `localhost` | Redis instance hostname |
| `GEMINI_API_KEY` | (None) | Google Generative AI validation key |
| `AI_SERVICE_URL` | `http://localhost:8000` | FastAPI connection URL |
| `APP_CORS_ALLOWED_ORIGINS` | `http://localhost:5173` | CORS allowed client endpoints |

---

## 7. Dependencies

### Backend Dependencies (`pom.xml`)
* **Spring Boot Starter Web**: Serves RESTful endpoints.
* **Spring Boot Starter Data JPA**: Integrates Hibernate ORM mapping.
* **Spring Boot Starter Security**: Configures JWT filters and authorizations.
* **Spring Boot Starter Data Redis**: Interfaces client cache queries.
* **Spring Boot Starter WebSocket**: Facilitates real-time events.
* **MySQL Connector J**: Database driver.
* **io.jsonwebtoken (jjwt-api, jjwt-impl, jjwt-jackson)**: Standard library used to construct and parse tokens.
* **Project Lombok**: Automates constructor, getter, setter, and builder creation.
* **Springdoc OpenAPI UI**: Exposes Swagger API definitions.

### AI Service Dependencies (`requirements.txt`)
* **fastapi**: Main web app framework.
* **google-generativeai**: SDK mapping requests to Google Gemini model services.
* **PyMuPDF**: Reads and parses PDF documents.
* **python-docx**: Reads and parses Word files.
* **spacy**: Implements lightweight local parsing algorithms.

### Frontend Dependencies (`package.json`)
* **react & react-dom**: Core UI runtime.
* **react-router-dom**: Layout routing engine.
* **axios**: Handles HTTP calls with interceptors.
* **@mediapipe/tasks-vision**: Google MediaPipe FaceLandmarker WebAssembly engine.
* **chart.js & react-chartjs-2**: Renders analytical widgets.
* **react-hot-toast**: Triggers toast notifications.
* **@stomp/stompjs & sockjs-client**: Maps real-time socket connections.

---

## 8. Setup & Run Instructions

### Prerequisites
* Java 21 JDK
* Python 3.12 (with `venv` and `pip`)
* Node.js v18+ (with `npm`)
* Docker & Docker Compose

### 8.1 Setup with Docker Compose (Recommended)
This launches MySQL, Redis, Nginx, the Python AI Service, the Spring Boot Backend, and the React Frontend simultaneously:

1. Clone the repository and navigate to the project directory:
   ```bash
   cd D:/Antigravity/interview-iq
   ```
2. Create an `.env` file in the root directory and add your Google Gemini API key:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
3. Boot the system:
   ```bash
   docker-compose up --build
   ```
4. Access the application at `http://localhost`.

### 8.2 Manual Local Setup (Step-by-Step)

#### Step 1: Start MySQL and Redis
Ensure local instances of MySQL (port 3306, database `interviewiq`, username `root`, password `root123`) and Redis (port 6379) are active.

#### Step 2: Configure & Start the Python AI Service
1. Navigate to the AI service directory:
   ```bash
   cd ai-service
   ```
2. Create a virtual environment and activate it:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # Linux/macOS:
   source .venv/bin/activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Add your API key to `ai-service/.env`:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
5. Run the service using Uvicorn:
   ```bash
   python main.py
   ```
   *The AI service will run on `http://localhost:8000`.*

#### Step 3: Run the Spring Boot Backend
1. Navigate to the backend directory:
   ```bash
   cd ../backend
   ```
2. Build and run using the Maven wrapper:
   ```bash
   # Windows:
   mvnw.cmd spring-boot:run
   # Linux/macOS:
   ./mvnw spring-boot:run
   ```
   *The backend service will run on `http://localhost:8080`.*

#### Step 4: Run the React Frontend
1. Navigate to the frontend directory:
   ```bash
   cd ../frontend
   ```
2. Install package dependencies:
   ```bash
   npm install
   ```
3. Launch the development server:
   ```bash
   npm run dev
   ```
   *The frontend will run on `http://localhost:5173`.*

---

## 9. Known Issues, Technical Debt & Security Risks

During code review and directory auditing, several architectural anomalies and security risks were identified:

### ⚠️ Security Risks
1. **Exposure of Secrets in Version Control**:
   The deployment file [render.yaml](file:///D:/Antigravity/interview-iq/render.yaml) contains **hardcoded active API keys and production database credentials** on lines 12, 24, 26, and 28:
   * `GEMINI_API_KEY`: `AIzaSyAZJfGqRUCq2voHvGDgMSuH__UNUgtvwQI`
   * `SPRING_DATASOURCE_URL`: `jdbc:mysql://mysql-4e99f98-thakashiq-268.d.aivencloud.com:26917/...`
   * `SPRING_DATASOURCE_PASSWORD`: `AVNS_g-HY_irvGBh1W7savhR`
   * **Action Required**: Immediately invalidate these keys/passwords, delete this version-controlled file from public repository history, and map credentials strictly using environment variables.

### ⚙️ Technical Debt & Duplicate Files
1. **Orphaned Source Code**:
   There is a duplicate repository file [AuditLogRepository.java](file:///D:/Antigravity/interview-iq/repository/AuditLogRepository.java) located in a root-level `repository` folder outside the `backend/` directory structure.
   * **Action Required**: Remove the folder `D:\Antigravity\interview-iq\repository` entirely as it is redundant and ignored by the build script.

2. **Inactive Cache Declarations**:
   The file [application.yml](file:///D:/Antigravity/interview-iq/backend/src/main/resources/application.yml#L36) defines `spring.cache.type: simple` (concurrent hash map) despite the presence of [RedisConfig.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/config/RedisConfig.java) which registers a custom `RedisCacheManager`.
   * **Action Required**: Update cache configurations to ensure CacheManager injection initializes Redis cache drivers when docker instances are booted.

3. **Missing Test Suites**:
   The backend declared dependencies on `spring-boot-starter-test` and `spring-security-test` inside [pom.xml](file:///D:/Antigravity/interview-iq/backend/pom.xml#L97-L108) but has **no tests implemented** inside [backend/src/test](file:///D:/Antigravity/interview-iq/backend/src/test) (which does not exist).
   * **Action Required**: Add JUnit and Mockito test files to validate critical authentication, session completion, and proctoring logic.

---

## 10. Suggested Improvements

### 1. Centralize Caching and Caching Annotations
Inject standard Spring `@Cacheable` and `@CacheEvict` annotations directly into read-heavy service classes, such as:
* [QuestionServiceImpl.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/service/impl/QuestionServiceImpl.java#L34) (cache generated questions).
* Admin statistics methods inside [AdminController.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/controller/AdminController.java#L125).

### 2. Standardize Document Object Mappers
Create a unified mapper class (using MapStruct or simple model converters) instead of writing ad-hoc JSON conversion logic inside service files (e.g., in [ResumeServiceImpl.java](file:///D:/Antigravity/interview-iq/backend/src/main/java/com/interviewiq/service/impl/ResumeServiceImpl.java#L275) mapping suggestions JSON string fields).

### 3. Implement Database Migrations
Introduce **Flyway** or **Liquibase** migration scripts instead of relying on `hibernate.ddl-auto: update` in production environments, to ensure safe and predictable schema evolutions.
